
// nome do arquivo - dados.js
const usuarios = `
  [
    {
      "nome": "Admin",
      "email": "teste@email.com",
      "senha" : 1234
    }
  ]
`